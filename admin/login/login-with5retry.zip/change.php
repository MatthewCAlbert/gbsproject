<?php
    require "../include/server.php";
    $password='admin';
    $hashedPw = password_hash("$password",PASSWORD_BCRYPT);
    echo $hashedPw;
    $sql = "UPDATE `admin` SET `password`='$hashedPw' WHERE `username`='root'";
    $res = $conn->query($sql);
    $count = mysqli_affected_rows($res);
    echo $count;